"""The one production module that talks to Qdrant.

Everything third-party lives here: the client, its point/vector types, its distance enum and its
exceptions. Callers above this module only see project-owned types.
"""

from __future__ import annotations

import json
import socket
import uuid
from dataclasses import dataclass
from typing import Any, Callable, Sequence
from uuid import UUID

from qdrant_client import QdrantClient
from qdrant_client.http import models as rest

from packages.contracts.chunks import Chunk
from packages.contracts.indexing import EmbeddingRecord
from packages.contracts.storage import PayloadField

from .config import Distance, StorageConfig

RETRYABLE_STATUSES = frozenset({408, 429, 500, 502, 503, 504})

_DISTANCE_TO_SDK = {
    Distance.COSINE: rest.Distance.COSINE,
    Distance.DOT: rest.Distance.DOT,
    Distance.EUCLID: rest.Distance.EUCLID,
    Distance.MANHATTAN: rest.Distance.MANHATTAN,
}


class AdapterTransientError(Exception):
    """A failure that may succeed on retry (timeout, rate limit, temporary server status)."""


class AdapterPermanentError(Exception):
    """A failure that will not change on retry (rejected request, malformed response)."""


class AdapterUnavailableError(Exception):
    """The target could not be reached at all."""


@dataclass(frozen=True)
class TargetCollectionProfile:
    """Vector profile read from the target collection."""

    collection_name: str
    vector_name: str
    vector_size: int
    distance: str


def point_id_for(source_id: str, version: str, generation_id: str, chunk_id: str) -> UUID:
    """Deterministic point identity; inputs are JSON-encoded, never delimiter-joined."""
    return uuid.uuid5(uuid.NAMESPACE_URL, json.dumps([source_id, version, generation_id, chunk_id]))


def _as_uuid(value: Any) -> Any:
    """The client may hand ids back as strings; the public boundary always speaks UUID."""
    if isinstance(value, UUID):
        return value
    try:
        return UUID(str(value))
    except (TypeError, ValueError):
        return value


def build_payload(chunk: Chunk, embedding: EmbeddingRecord, generation_id: str) -> dict[str, Any]:
    """Map landed contract values onto the single shared payload definition."""
    source = chunk.source
    return {
        PayloadField.CHUNK_ID: chunk.chunk_id,
        PayloadField.GENERATION_ID: generation_id,
        PayloadField.MODEL_ID: embedding.model_id,
        PayloadField.SOURCE_ID: source.source.source_id,
        PayloadField.VERSION: source.version,
        PayloadField.KNOWLEDGE_SPACE_ID: source.source.knowledge_space_id,
        PayloadField.SOURCE_TYPE: source.source.source_type,
        PayloadField.KIND: chunk.kind,
        PayloadField.TEXT: chunk.text,
        PayloadField.LOCATION: chunk.location.model_dump() if chunk.location is not None else None,
        PayloadField.TENANT_ID: chunk.access.tenant_id,
        PayloadField.ACL_PRINCIPALS: list(chunk.access.acl_principals),
        PayloadField.SYMBOL_ID: chunk.symbol_id,
        PayloadField.METADATA: dict(chunk.metadata),
    }


def _chain(exc: BaseException):
    """Yield the exception and its cause/context chain (cycle-safe)."""
    seen: set[int] = set()
    current: BaseException | None = exc
    while current is not None and id(current) not in seen:
        seen.add(id(current))
        yield current
        current = current.__cause__ or current.__context__


def _translate(exc: BaseException) -> Exception:
    """Classify an exception into the adapter's own project-owned error taxonomy."""
    if isinstance(exc, (AdapterTransientError, AdapterPermanentError, AdapterUnavailableError)):
        return exc

    chain = list(_chain(exc))

    for link in chain:
        status = getattr(link, "status_code", None)
        if status is not None:
            if status in RETRYABLE_STATUSES:
                return AdapterTransientError(str(exc))
            return AdapterPermanentError(str(exc))

    names = [type(link).__name__ for link in chain]
    # "cannot reach the target at all" wins over "the target was slow"
    if any(
        token in name
        for name in names
        for token in ("Connect", "Network", "Protocol", "ResponseHandling", "Proxy")
    ) or any(isinstance(link, (ConnectionError, OSError)) for link in chain[:-1]):
        if any("Timeout" in name or "TimedOut" in name for name in names):
            return AdapterUnavailableError(str(exc))
        return AdapterUnavailableError(str(exc))
    if any("Timeout" in name for name in names) or any(
        isinstance(link, (TimeoutError, socket.timeout)) for link in chain
    ):
        return AdapterTransientError(str(exc))
    if isinstance(exc, OSError):
        return AdapterUnavailableError(str(exc))
    return AdapterPermanentError(str(exc))


class QdrantAdapter:
    """Thin, retrying wrapper over the Qdrant client. No business decisions live here."""

    def __init__(self, config: StorageConfig, client: Any | None = None) -> None:
        self._config = config
        self._client = client

    @property
    def client(self) -> Any:
        if self._client is None:
            self._client = QdrantClient(
                url=self._config.url,
                timeout=self._sdk_timeout(),
                prefer_grpc=False,
                check_compatibility=False,
            )
        return self._client

    def _sdk_timeout(self) -> int:
        """The client takes whole seconds; the project config keeps a float."""
        return max(1, int(round(self._config.timeout_seconds)))

    # ---- collection profile

    def profile(self) -> TargetCollectionProfile:
        info = self._with_retries(
            lambda: self.client.get_collection(collection_name=self._config.collection_name)
        )
        vectors = info.config.params.vectors
        named = vectors[self._config.vector_name] if isinstance(vectors, dict) else vectors
        distance = getattr(named.distance, "value", str(named.distance))
        return TargetCollectionProfile(
            collection_name=self._config.collection_name,
            vector_name=self._config.vector_name,
            vector_size=int(named.size),
            distance=str(distance),
        )

    # ---- write

    def write_group(self, points: Sequence[tuple[UUID, Sequence[float], dict[str, Any]]]) -> None:
        structs = [
            rest.PointStruct(
                id=point_id,
                vector={self._config.vector_name: list(vector)},
                payload=payload,
            )
            for point_id, vector, payload in points
        ]
        self._with_retries(
            lambda: self.client.upsert(
                collection_name=self._config.collection_name,
                points=structs,
                wait=True,
                timeout=self._sdk_timeout(),
            )
        )

    # ---- read

    def read(self, ids: Sequence[UUID]) -> dict[UUID, tuple[dict[str, Any], list[float]]]:
        records = self._with_retries(
            lambda: self.client.retrieve(
                collection_name=self._config.collection_name,
                ids=list(ids),
                with_payload=True,
                with_vectors=True,
            )
        )
        found: dict[UUID, tuple[dict[str, Any], list[float]]] = {}
        for record in records:
            vector = record.vector
            if isinstance(vector, dict):
                vector = vector.get(self._config.vector_name, [])
            found[_as_uuid(record.id)] = (dict(record.payload or {}), list(vector or []))
        return found

    # ---- retry policy: fixed small bound, no server-directed delay

    def _with_retries(self, call: Callable[[], Any]) -> Any:
        attempt = 0
        while True:
            try:
                return call()
            except Exception as exc:  # noqa: BLE001 - classified below
                failure = _translate(exc)
                if isinstance(failure, AdapterTransientError) and attempt < self._config.max_retries:
                    attempt += 1
                    if self._config.retry_backoff_seconds:
                        self._config.sleep(self._config.retry_backoff_seconds)
                    continue
                raise failure from exc
